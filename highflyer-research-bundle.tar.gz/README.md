# 波浪候选扫描：公开只读版

这是一个不依赖个人电脑的静态扫描网站：

- GitHub Actions 在云端扫描 A 股、美股和黄金相关标的。
- GitHub Pages 只发布候选列表，不运行可写后台。
- 默认在北京时间工作日 15:30 和次日 06:30 更新。
- 页面不包含持仓、观察名单、Telegram、日志或行情缓存。

## 均衡型 V3 扫描规则

- 股票池：最多 800 只流动性较好的 A 股、300 只美股大盘与活跃股，以及 2 个黄金标的。
- 浪级：周线识别大级别结构，日线识别中级别结构；两个级别同向时增加结构分。
- 形态：2 浪回撤、4 浪回踩、3 浪突破和 ABC/C 浪末端分别识别。
- 阶段：严格限定的支撑附近机会归入“左侧试错”，出现支撑收复、更高低点或放量突破后归入“右侧触发”，两者都计入买入提醒。
- 评分：结构 35 分、位置 25 分、确认 20 分、趋势 10 分、盈亏比 10 分。
- 大盘：同步观察上证指数、沪深300、标普500和纳斯达克综合；大盘震荡扣 3 分，偏弱扣 8 分。
- 硬过滤：低于失效位、距离支撑过远、盈亏比不足 1.5:1 或总分低于 65 的候选不发布。
- 分档：85 分以上优先并直接展示，85 分以下默认折叠；75-84 分较强，65-74 分观察。
- 页面：固定中英双语展示，中文为主、英文为辅；作者署名 Astrid。
- 历史验证：每天保存仅含 85 分以上买入提醒的公开快照；同一标的连续处于高分区只按首次进入记录一次，跟踪 5、21、63、126 个交易日的胜率与收益率。

历史统计从功能上线后开始前向积累，不用今天的算法倒推过去，也不把尚未走完周期的信号提前计入胜率。每日快照和信号账本位于 `site/data/history/`，由 GitHub Actions 自动写回仓库。

> 仅供研究参考，不构成投资建议。波浪识别具有主观性，历史形态不代表未来表现。

## 发布步骤

1. 在 GitHub 新建一个空仓库。
2. 将本目录中的全部文件上传到仓库默认分支。
3. 打开仓库 `Settings > Pages`，将 `Source` 设为 `GitHub Actions`。
4. 打开 `Actions > Public Wave Scan`，点击 `Run workflow`。
5. 首次扫描完成后，在工作流的 `deploy` 页面打开公开网址。

后续无需保持个人电脑开机。定时任务由 GitHub 运行，网站由 GitHub Pages 提供。

## 本地验证

```bash
python3 -m unittest discover -s tests
python3 scripts/privacy_check.py
```

本地完整扫描：

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 scripts/run_public_scan.py
```

## 隐私边界

`site/` 是唯一会发布的目录。发布前工作流会自动运行 `scripts/privacy_check.py`，并检查候选数据及历史快照；发现以下内容时终止发布：

- 私人配置或观察名单文件
- Telegram 地址、令牌形态或密钥
- 已知个人路径或个人标识
- 原本地应用地址

扫描缓存与原始失败日志只存在于 GitHub Actions 缓存中，不会进入 Pages 网站。

## 幻方公开足迹研究

`research/highflyer/` 是独立研究模块，只分析巨潮资讯公开定期报告。流程包括公告索引、PDF 股东表核验、报告期特征，以及从首次公告后下一交易日开始的 21/63 日跟随回测。

```bash
python3 -m research.highflyer.collect_public_footprints --start 2019-01-01
python3 -m research.highflyer.verify_public_footprints
python3 -m research.highflyer.analyze_public_footprints
```

研究报告位于 `research/highflyer/output/report.md`。原始接口响应、PDF 和行情缓存均被忽略，不会发布到 GitHub Pages。公开股东快照不是完整交易记录，也不能还原幻方的私有模型、实际成本或对冲仓位。
